export class QdbBanner extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    get title() {
        return this.getAttribute('title');
    }

    get subtitle() {
        return this.getAttribute('subtitle');
    }

    get fill() {
        return this.getAttribute('fill');
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                .container {
                    position: relative;
                    display: flex;
                    justify-content: center;
                    flex-direction: column;
                    height: 125px;
                    color: var(--offWhite);
                    font-variant: all-petite-caps;
                    text-align: center;
                }
                svg {
                    position: absolute;
                    z-index: 0;
                }
                .title,
                .subtitle {
                    width: 100%;
                    z-index: 99;
                    line-height: 3.5rem;
                }
                .title {
                    font-size: 5rem;
                }
                .subtitle {
                    font-size: 3rem;
                }
            </style>
            <div class="container">
                <span class="title">${this.title}</span>
                <span class="subtitle">${this.subtitle}</span>
                <svg width="1080" height="125" viewBox="0 0 1080 155">
                    <path 
                    d="m -36.32034,77.684909 -93.15733,-77.54296035 669.78923,0 576.47674,0.15040894 92.8798,76.94254741 -93.1705,77.994385 -576.18604,-0.0729 -669.78923,0 z"
                    style="fill:${this.fill}" />
                </svg>
            </div>
        `
    }
}

customElements.define('quality-dashboard-banner', QdbBanner);