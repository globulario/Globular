import { Model } from "./Model";
import { ApplicationView } from "./ApplicationView";
import { Account } from "./Account";
import { NotificationType, Notification } from "./Notification";
/**
 * That class can be use to create any other application.
 */
export declare class Application extends Model {
    static uuid: string;
    static language: string;
    private static infos;
    private contactsListener;
    private _appConfig;
    get appConfig(): any;
    set appConfig(value: any);
    private _name;
    get name(): string;
    set name(value: string);
    private _title;
    get title(): string;
    set title(value: string);
    private _id;
    get id(): string;
    set id(value: string);
    private _path;
    get path(): string;
    set path(value: string);
    protected account: Account;
    private login_event_listener;
    private register_event_listener;
    private logout_event_listener;
    private delete_notification_event_listener;
    private invite_contact_listener;
    private settings_event_listener;
    /**
     * Create a new application with a given name. The view
     * can be any ApplicationView or derived ApplicationView class.
     * @param name The name of the application.
     */
    constructor(name: string, title: string, view: ApplicationView);
    /**
     * Get value from config.json file if any...
     * @param callback
     */
    initApplicationConfig(callback: (config: any) => void, errorCallback: (err: any) => void): void;
    /**
     * Connect the listner's and call the initcallback.
     * @param url the backend url.
     * @param initCallback
     * @param errorCallback
     * @param configurationPort
     */
    init(url: string, initCallback: () => void, errorCallback: (err: any) => void): void;
    /**
     * Return the list of all applicaitons informations.
     * @param callback
     * @param errorCallback
     */
    static getAllApplicationInfo(callback: (infos: Array<any>) => void, errorCallback: (err: any) => void): void;
    /**
     * Return application infos.
     * @param id
     */
    static getApplicationInfo(id: string): any;
    /**
     * Return partial information only.
     */
    toString(): string;
    /**
     * Display true if a session is open.
     */
    get isLogged(): boolean;
    /**
     * Refresh the token and open a new session if the token is valid.
     */
    private refreshToken;
    /**
     * Refresh the token to keep it usable.
     */
    private startRefreshToken;
    /**
     * Register a new account with the application.
     * @param name The account name
     * @param email The account email
     * @param password The account password
     */
    register(name: string, email: string, password: string, confirmPassord: string, onRegister: (account: Account) => void, onError: (err: any) => void): Account;
    addContactListener(contact: any): void;
    /**
     * Login into the application
     * @param email
     * @param password
     */
    login(email: string, password: string, onLogin: (account: Account) => void, onError: (err: any) => void): void;
    /**
     * Close the current session explicitelty.
     */
    logout(): void;
    /**
     * Exit application.
     */
    exit(): void;
    /**
     * Settings application.
     */
    settings(): void;
    displayMessage(msg: any, delay: number): any;
    /**
     * That function must be use to update application information store
     * in level db in local_ressource table.
     * @param id
     * @param info
     */
    static saveApplicationInfo(id: string, info: any, successCallback: (infos: any) => void, errorCallback: (err: any) => void): void;
    onCreateNewConversation(): void;
    /**
     * Initialyse the user and application notifications
     */
    private initNotifications;
    /**
     * Send application notifications.
     * @param notification The notification can contain html text.
     */
    sendNotifications(notification: Notification, callback: () => void, onError: (err: any) => void): void;
    /**
     *  Retreive the list of nofitications
     * @param callback The success callback with the list of notifications.
     * @param errorCallback The error callback with the error message.
     */
    getNotifications(type: NotificationType, callback: (notifications: Array<Notification>) => void, errorCallback: (err: any) => void): void;
    removeNotification(notification: Notification): void;
    /**
     * Remove all notification.
     */
    clearNotifications(type: NotificationType): void;
    onInviteContact(contact: Account): void;
    onAcceptContactInvitation(contact: Account): void;
    onDeclineContactInvitation(contact: Account): void;
    onRevokeContactInvitation(contact: Account): void;
    onDeleteContact(contact: Account): void;
}
