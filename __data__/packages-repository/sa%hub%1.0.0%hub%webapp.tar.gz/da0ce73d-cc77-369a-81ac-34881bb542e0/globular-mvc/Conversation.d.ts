import { Conversation, Conversations, Message } from "globular-web-client/conversation/conversation_pb";
import { Account } from "./Account";
export declare class ConversationManager {
    static uuid: string;
    constructor();
    static connect(successCallback: (uuid: string) => void, errorCallback: (err: any) => void): void;
    /**
     * Create a new conversation.
     * @param name
     * @param keywords
     * @param language
     * @param succesCallback
     * @param errorCallback
     */
    static createConversation(name: string, keywords: Array<string>, language: any, succesCallback: (conversation: Conversation) => void, errorCallback: (err: any) => void): void;
    /**
     * Load conversation owned by a given account.
     * @param account Must by the logged account.
     * @param succesCallback Return the list of conversation owned by the account.
     * @param errorCallback Error if any.
     */
    static loadOwnedConversation(account: Account, succesCallback: (conversations: Conversations) => void, errorCallback: (err: any) => void): void;
    static deleteConversation(conversationUuid: string, succesCallback: () => void, errorCallback: (err: any) => void): void;
    static findConversations(query: string, succesCallback: (conversations: Conversation[]) => void, errorCallback: (err: any) => void): void;
    static joinConversation(conversationUuid: string, succesCallback: (messages: Message[]) => void, errorCallback: (err: any) => void): void;
    static sendMessage(conversationUuid: string, author: string, text: string, replyTo: string, successCallback: () => void, errorCallback: () => void): void;
}
