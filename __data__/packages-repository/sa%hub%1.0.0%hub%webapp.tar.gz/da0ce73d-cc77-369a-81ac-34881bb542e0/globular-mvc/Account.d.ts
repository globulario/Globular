import { Model } from "./Model";
/**
 * The session object will keep information about the
 * the account.
 */
export declare enum SessionState {
    Online = 0,
    Offline = 1,
    Away = 2
}
export declare class Session extends Model {
    private _id;
    private state_;
    private lastStateTime;
    get state(): SessionState;
    set state(value: SessionState);
    constructor(accountId: string, state?: number, lastStateTime?: string);
    initData(initCallback: () => void, errorCallback: (err: any) => void): void;
    toString(): string;
    fromObject(obj: any): void;
    save(onSave: () => void, onError: (err: any) => void): void;
}
/**
 * Basic account class that contain the user id and email.
 */
export declare class Account extends Model {
    private static listeners;
    private static accounts;
    private groups_;
    private session_;
    get session(): Session;
    set session(value: Session);
    private _id;
    get id(): string;
    set id(value: string);
    private name_;
    get name(): string;
    set name(value: string);
    private email_;
    get email(): string;
    set email(value: string);
    private hasData;
    private profilPicture_;
    get profilPicture(): string;
    set profilPicture(value: string);
    private firstName_;
    get firstName(): string;
    set firstName(value: string);
    private lastName_;
    get lastName(): string;
    set lastName(value: string);
    private middleName_;
    get middleName(): string;
    set middleName(value: string);
    get userName(): string;
    constructor(id: string, email: string, name: string);
    /**
     * Get an account with a given id.
     * @param id The id of the account to retreive
     * @param successCallback Callback when succed
     * @param errorCallback Error Callback.
     */
    static getAccount(id: string, successCallback: (account: Account) => void, errorCallback: (err: any) => void): void;
    /**
     * Initialyse account groups.
     * @param obj The account data from the persistence store.
     * @param successCallback
     * @param errorCallback
     */
    private initGroups;
    isMemberOf(groupName: string): boolean;
    static setAccount(a: Account): void;
    private static getListener;
    private static setListener;
    private static unsetListener;
    /**
     * Read user data one result at time.
     */
    private static readOneUserData;
    private setData;
    /**
     * Must be called once when the session open.
     * @param account
     */
    initData(callback: (account: Account) => void, onError: (err: any) => void): void;
    /**
     * Change the user profil picture...
     * @param dataUrl The data url of the new profile picture.
     * @param onSaveAccount The success callback
     * @param onError The error callback
     */
    changeProfilImage(dataUrl: string): void;
    /**
     * Save user data into the user_data collection. Insert one or replace one depending if values
     * are present in the firstName and lastName.
     */
    save(callback: (account: Account) => void, onError: (err: any) => void): void;
    static getContacts(userName: string, query: string, callback: (contacts: Array<any>) => void, errorCallback: (err: any) => void): void;
    static setContact(from: string, status_from: string, to: string, status_to: string, successCallback: () => void, errorCallback: (err: any) => void): void;
    static getAccounts(query: string, callback: (accounts: Array<Account>) => void, errorCallback: (err: any) => void): void;
}
