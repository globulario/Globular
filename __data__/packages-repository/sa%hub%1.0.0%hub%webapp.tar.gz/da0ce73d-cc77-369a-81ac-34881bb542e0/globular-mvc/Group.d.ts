import { Model } from "./Model";
import { Account } from "./Account";
/**
 * Group are use to aggregate accounts.
 */
export declare class Group extends Model {
    private static listeners;
    private static groups;
    private _id;
    get id(): string;
    private _name;
    get name(): string;
    set name(value: string);
    private members;
    constructor(id: string);
    initData(initCallback: () => void, errorCallback: (err: any) => void): void;
    static getGroup(id: string, successCallback: (g: Group) => void, errorCallback: (err: any) => void): void;
    save(successCallback: (g: Group) => void, errorCallback: (err: any) => void): void;
    getMembers(successCallback: (members: Array<Account>) => void, errorCallback: () => void): void;
    hasMember(account: Account): boolean;
    toString(): string;
    fromObject(obj: any): void;
}
