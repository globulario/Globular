import { Account } from "./Account";
import { Application } from "./Application";
import { SettingsMenu, SettingsPanel } from "./components/Settings";
export declare class Settings {
    protected settingsMenu: SettingsMenu;
    protected settingsPanel: SettingsPanel;
    constructor(settingsMenu: SettingsMenu, settingsPanel: SettingsPanel);
    load(): void;
    save(): void;
}
/**
 * Model for user settings.
 */
export declare class UserSettings extends Settings {
    private account;
    constructor(account: Account, settingsMenu: SettingsMenu, settingsPanel: SettingsPanel);
}
/**
 * Model to save application settings.
 */
export declare class ApplicationSettings extends Settings {
    private application;
    constructor(application: Application, settingsMenu: SettingsMenu, settingsPanel: SettingsPanel);
}
