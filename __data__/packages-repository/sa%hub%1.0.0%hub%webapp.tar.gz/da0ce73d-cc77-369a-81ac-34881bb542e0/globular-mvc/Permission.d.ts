import * as rbac from "globular-web-client/rbac/rbac_pb";
/**
 * That class is use to access Ressource permission.
 */
export declare class PermissionManager {
    constructor();
    /**
     * Return the ressource permission for a given ressource.
     * @param subject The account, organization, group, peer to give permission to.
     * @param ressource The ressource to set
     * @param permission Can be any string, it will be drive by the interface here.
     */
    static getRessourcePermission(ressource: string, permission: string, type: rbac.PermissionType, successCallback: (permission: rbac.Permission) => void, errorCallback: (err: any) => void, subject?: string): void;
    /**
     * Return the ressource permission for a given ressource.
     * @param subject The account, organization, group, peer to give permission to.
     * @param ressource The ressource to set
     * @param permission Can be any string, it will be drive by the interface here.
     */
    static getRessourcePermissions(ressource: string, successCallback: (permissions: rbac.Permissions) => void, errorCallback: (err: any) => void): void;
    /**
     * Create/Set a permission for a ressource.
     * @param subject The account, organization, group, peer to give permission to.
     * @param ressource The ressource to set
     * @param permission Can be any string, it will be drive by the interface here.
     */
    static setRessourcePermissions(ressource: string, permission: string, subject: string, successCallback: () => void, errorCallback: (err: any) => void): void;
    /**
     * Remove ressource permissions or if permission and suject is set it will remove
     * only for a specif permission and subject.
     * @param subject The account, organization, group, peer to give permission to.
     * @param ressource The ressource to set
     * @param permission Can be any string, it will be drive by the interface here.
     */
    static removeRessourcePermissions(ressource: string, permission?: string, subject?: string): void;
}
