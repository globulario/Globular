export declare function mergeTypedArrays(a: any, b: any): any;
export declare function uint8arrayToStringMethod(uint8arr: any, callback: (str: any) => void): void;
