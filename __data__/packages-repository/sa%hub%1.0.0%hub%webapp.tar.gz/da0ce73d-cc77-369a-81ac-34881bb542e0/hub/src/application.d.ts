import "materialize-css/sass/materialize.scss";
import { Application } from "../../globular-mvc/Application";
import { ApplicationView } from "../../globular-mvc/ApplicationView";
import { Account } from "../../globular-mvc/Account";
import "../../globular-mvc/node_modules/@polymer/iron-selector/iron-selector";
export declare class HubApplicationView extends ApplicationView {
    displayWelcomePage: () => void;
    private welcomeContent;
    constructor();
    onLogin(account: Account): void;
    onLogout(): void;
}
export declare class HubApplication extends Application {
    constructor(view: HubApplicationView);
}
