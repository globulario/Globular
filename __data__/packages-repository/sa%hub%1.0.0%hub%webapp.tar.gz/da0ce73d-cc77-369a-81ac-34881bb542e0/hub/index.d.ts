import "./css/main.css";
import "./css/welcome.css";
import "../globular-mvc/components/Image";
